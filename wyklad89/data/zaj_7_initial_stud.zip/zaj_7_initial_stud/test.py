from settings import Session

__author__ = 'jb'

from orm_example import *

b = TabB()

sess = Session()
